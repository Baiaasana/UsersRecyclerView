package com.example.usersrecyclerview

data class UserData(
    var firstName:  String,
    var lastName: String,
    var mail: String
)