package com.example.usersrecyclerview

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.usersrecyclerview.databinding.ActivityAddItemBinding
import com.example.usersrecyclerview.databinding.ActivityUserBinding

class UserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserBinding
    private lateinit var binding2: ActivityAddItemBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var userList: ArrayList<UserData>
    private lateinit var userAdapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userList = ArrayList()
        recyclerView = binding.recyclerView
        userAdapter = UserAdapter(this, userList)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = userAdapter

        binding.btnAdd.setOnClickListener {
            addInfo()
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun addInfo() {

        binding2 = ActivityAddItemBinding.inflate(layoutInflater)

        val firstname = binding2.edtAddName
        val lastname = binding2.edtAddLastName
        val mail = binding2.edtAddMail

        val addDialog = AlertDialog.Builder(this)
        addDialog.setView(binding2.root)
            .setIcon(R.drawable.ic_baseline_playlist_add_24)
            .setTitle("Add User Info")
        addDialog.setPositiveButton("Add user") { dialog, _ ->
            val names = firstname.text.toString()
            val lastnames = lastname.text.toString()
            val mails = mail.text.toString()

            userList.add(UserData(names, lastnames, mails))
            userAdapter.notifyDataSetChanged()
            Toast.makeText(this, "User Information added successfully!", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        addDialog.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
            Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show()
        }
        addDialog.create()
        addDialog.show()
    }
}